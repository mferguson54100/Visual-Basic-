﻿Public Class Form1
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim strCount As String
        Dim strName As String
        Dim strPhoneNumber As String
        Dim intIndex As Integer
        Dim intCount As Integer
        Dim intPhoneNumber As Integer

        strName = InputBox("enter a name")
        strPhoneNumber = InputBox("enter a phone number")
        'add
        lbname.Items.Add(strName)

        If Integer.TryParse(strPhoneNumber, intPhoneNumber) Then
            If intPhoneNumber >= 0 Then
                lbPhoneNumber.Items.Add(strPhoneNumber)
            Else
                MessageBox.Show("enter a valid integer")
            End If
        End If

        'add serial 
        Do While intCount < lbname.Items.Count



            intCount += 1




        Loop
        lbSerial.Items.Add(intCount)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim strCount As String
        Dim intCount As Integer

        strCount = InputBox("enter a serial number")

        If Integer.TryParse(strCount, intCount) Then

            Do While intCount - 1 < lbname.Items.Count
                MessageBox.Show(lbname.Items(intCount - 1) & "s phone number is " & lbPhoneNumber.Items(intCount - 1))

                intCount += 1
            Loop

        Else
            MessageBox.Show("enter a vaild integer")
        End If






    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        lbPhoneNumber.Items.Clear()
        lbname.Items.Clear()
        lbSerial.Items.Clear()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()

    End Sub
End Class
