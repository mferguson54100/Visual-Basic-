﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.liStudName = New System.Windows.Forms.ListBox()
        Me.liStudGrade = New System.Windows.Forms.ListBox()
        Me.lblSrudAvg1 = New System.Windows.Forms.Label()
        Me.btnStud = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.lblstudavg3 = New System.Windows.Forms.Label()
        Me.lblstudavg2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'liStudName
        '
        Me.liStudName.FormattingEnabled = True
        Me.liStudName.Location = New System.Drawing.Point(0, 0)
        Me.liStudName.Name = "liStudName"
        Me.liStudName.Size = New System.Drawing.Size(120, 95)
        Me.liStudName.TabIndex = 0
        '
        'liStudGrade
        '
        Me.liStudGrade.FormattingEnabled = True
        Me.liStudGrade.Location = New System.Drawing.Point(126, 0)
        Me.liStudGrade.Name = "liStudGrade"
        Me.liStudGrade.Size = New System.Drawing.Size(120, 95)
        Me.liStudGrade.TabIndex = 2
        '
        'lblSrudAvg1
        '
        Me.lblSrudAvg1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSrudAvg1.Location = New System.Drawing.Point(32, 184)
        Me.lblSrudAvg1.Name = "lblSrudAvg1"
        Me.lblSrudAvg1.Size = New System.Drawing.Size(123, 20)
        Me.lblSrudAvg1.TabIndex = 3
        '
        'btnStud
        '
        Me.btnStud.Location = New System.Drawing.Point(12, 144)
        Me.btnStud.Name = "btnStud"
        Me.btnStud.Size = New System.Drawing.Size(108, 23)
        Me.btnStud.TabIndex = 4
        Me.btnStud.Text = "Enter Student"
        Me.btnStud.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(135, 144)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(123, 23)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Enter Studnet Grades"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(283, 144)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "Calc Avg"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'lblstudavg3
        '
        Me.lblstudavg3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblstudavg3.Location = New System.Drawing.Point(310, 184)
        Me.lblstudavg3.Name = "lblstudavg3"
        Me.lblstudavg3.Size = New System.Drawing.Size(123, 20)
        Me.lblstudavg3.TabIndex = 7
        '
        'lblstudavg2
        '
        Me.lblstudavg2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblstudavg2.Location = New System.Drawing.Point(170, 184)
        Me.lblstudavg2.Name = "lblstudavg2"
        Me.lblstudavg2.Size = New System.Drawing.Size(123, 20)
        Me.lblstudavg2.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(187, 229)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "student 2"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(52, 229)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Student 1"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(337, 229)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Student 3"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(500, 261)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblstudavg2)
        Me.Controls.Add(Me.lblstudavg3)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnStud)
        Me.Controls.Add(Me.lblSrudAvg1)
        Me.Controls.Add(Me.liStudGrade)
        Me.Controls.Add(Me.liStudName)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents liStudName As ListBox
    Friend WithEvents liStudGrade As ListBox
    Friend WithEvents lblSrudAvg1 As Label
    Friend WithEvents btnStud As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents lblstudavg3 As Label
    Friend WithEvents lblstudavg2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class
