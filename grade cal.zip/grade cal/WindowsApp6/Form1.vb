﻿Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim strGrade As String
        Dim intGrade As Integer
        Dim intCount As Integer = 1
        Dim intIndex As Integer




        'enter gardes for each item in the name list box and for each item you can enter 3 gardes 
        Do While liStudName.Items.Count >= intCount
            strGrade = InputBox("enter grade for student# " & intCount)
            If Integer.TryParse(strGrade, intGrade) Then
                If intGrade > 0 Then
                    liStudGrade.Items.Add(intGrade)


                    For intIndex = 0 To 3
                        intGrade = InputBox("Enter garde for student#" & intCount)
                        liStudGrade.Items.Add(intGrade)
                        intIndex += 1
                    Next
                    intCount += 1
                Else
                    MessageBox.Show("enter a vaild grade")
                End If
            End If
        Loop





    End Sub
    'allows you to enter a student name into the student list box 
    Private Sub btnStud_Click(sender As Object, e As EventArgs) Handles btnStud.Click
        Dim strStudentName As String

        strStudentName = InputBox("enter students Name")
        liStudName.Items.Add(strStudentName)


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim intCount As Integer
        Dim intStudavg1 As Integer
        Dim intStudavg2 As Integer
        Dim intStudavg3 As Integer
        Dim StrLetterGrade1 As String
        Dim StrLetterGrade2 As String
        Dim StrLetterGrade3 As String


        Do While liStudGrade.Items.Count > intCount
            For intCount = 0 To 2
                intStudavg1 += liStudGrade.Items(intCount)
            Next
            For intCount = 3 To 5
                intStudavg2 += liStudGrade.Items(intCount)
            Next
            For intCount = 6 To 8
                intStudavg3 += liStudGrade.Items(intCount)
            Next
        Loop
        'calc the avg for each student 
        intStudavg1 = intStudavg1 / 3
        intStudavg2 = intStudavg2 / 3
        intStudavg3 = intStudavg3 / 3
        'calc the letter grade for each student 
        If intStudavg1 >= 90 Then
            StrLetterGrade1 = "A"
        ElseIf intStudavg1 >= 80 Then
            StrLetterGrade1 = "B"
        ElseIf intStudavg1 >= 70 Then
            StrLetterGrade1 = "C"
        ElseIf intStudavg1 >= 60 Then
            StrLetterGrade1 = "D"
        Else
            StrLetterGrade1 = "F"


        End If
        If intStudavg2 >= 90 Then
            StrLetterGrade2 = "A"
        ElseIf intStudavg2 >= 80 Then
            StrLetterGrade2 = "B"
        ElseIf intStudavg2 >= 70 Then
            StrLetterGrade2 = "C"
        ElseIf intStudavg2 >= 60 Then
            StrLetterGrade2 = "D"
        Else
            StrLetterGrade2 = "F"


        End If
        If intStudavg3 >= 90 Then
            StrLetterGrade3 = "A"
        ElseIf intStudavg3 >= 80 Then
            StrLetterGrade3 = "B"
        ElseIf intStudavg3 >= 70 Then
            StrLetterGrade3 = "C"
        ElseIf intStudavg3 >= 60 Then
            StrLetterGrade3 = "D"
        Else
            StrLetterGrade3 = "F"


        End If
        'displays the number and letter grade in a label 
        lblSrudAvg1.Text = intStudavg1.ToString & StrLetterGrade1.ToString
        lblstudavg2.Text = intStudavg2.ToString & StrLetterGrade2.ToString
        lblstudavg3.Text = intStudavg3.ToString & StrLetterGrade3.ToString


    End Sub
End Class
