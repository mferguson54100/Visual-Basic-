﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim strGuess As String
        Dim strWord As String
        Dim intCount As Integer = 0
        Dim intTrys As Integer = 3

        strWord = txtSecretWord.Text.ToString()



        Do While intCount < 3

            strGuess = InputBox("Ener your guess" & "Number of guesses left" & " " & intTrys)
            LiTrys.Items.Add(strGuess)

            If String.Equals(strGuess, strWord) Then
                MessageBox.Show("You Guess it")
                intCount = 3


            Else

                intCount += 1
                intTrys -= 1
            End If




        Loop
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        LiTrys.Items.Clear()


    End Sub
End Class
