﻿Public Class Form1
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim intRate As Integer

        If Integer.TryParse(txtrating.Text, intRate) Then
            If intRate >= 0 And intRate <= 4 Then
                lirate.Items.Add(txtrating.Text)

                liprof.Items.Add(txtprofname.Text)
            Else
                MessageBox.Show("enter a rating from 0-4")
            End If
        Else
            MessageBox.Show("enter a rating.")
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim decAvg As Decimal
        Dim decTotal As Decimal
        Dim intCount As Integer = 0
        If lirate.Items.Count > 0 Then
            Do While intCount < lirate.Items.Count
                decTotal += (lirate.Items(intCount))
                intCount += 1
            Loop

            decAvg = decTotal / lirate.Items.Count
            lblrate.Text = decAvg.ToString("n1")
            lbltot.Text = liprof.Items.Count
        Else
            MessageBox.Show("enter at least 1 Prof and rating.")
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        lbltot.Text = String.Empty
        lblrate.Text = String.Empty
        txtprofname.Clear()
        txtrating.Clear()
        liprof.Items.Clear()
        lirate.Items.Clear()

    End Sub
End Class
